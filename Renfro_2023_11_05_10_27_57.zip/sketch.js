function setup() {
  createCanvas(400, 400);
  background(0);
  frameRate(24);
}

let x = 5;
let y = 5;
let s = 1.1;
let angle = 2;
let number = 2;

function draw() {
  noLoop();
  fill('White');
  textSize(20);
  text('Score: ', 20, 30);
  text('0', 90, 30);
  stroke(255);
  line(165, 225, 175, 185);
  line(175, 185, 185, 225);
  line(165, 225, 175, 220);
  line(175, 220, 185, 225);
  for(let i = 0; i < 7; i++) {
    asteroid();
    checkUp();
    number++;
    x += 5;
    y += 5;
    s += 0.2;
    angle += 9;
  }
}

function asteroid() {
  stroke(255);
  line(100, 90, 115, 80);
  line(100, 90, 110, 90);
  line(110, 90, 110, 100);
  line(110, 100, 115, 100);
  line(115, 80, 120, 90);
  line(115, 100, 120, 90);
  angleMode(DEGREES);
  push();
  translate(x, y);
  scale(s);
  rotate(angle);
  line(100, 90, 115, 80);
  line(100, 90, 110, 90);
  line(110, 90, 110, 100);
  line(110, 100, 115, 100);
  line(115, 80, 120, 90);
  line(115, 100, 120, 90);
  pop();
}

function checkUp() {
  print('Translation of x coordinate is ' + x);
  print('Translation of y coordinate is ' + y);
  print('Scale of enlargement is ' + s);
  print('Angle of rotation is ' + angle);
  print('The number of asteroids is ' + number);
}
function setup() {
  createCanvas(128, 128);
  background(50);
}

function draw() {
  strokeCap(ROUND);
  rect(70, 60, 30, 70);
  rect(20, 90, 20, 40);
  noStroke();
  ellipse(50, 20, 40, 40);
  ellipse(80, 20, 2, 2);
  ellipse(95, 25, 2, 2);
  ellipse(100, 15, 2, 2);
  ellipse(105, 20, 2, 2);
  ellipse(100, 30, 2, 2);
  ellipse(110, 10, 2, 2);
  ellipse(115, 30, 2, 2);
  ellipse(120, 20, 2, 2);
  ellipse(85, 15, 2, 2);
  ellipse(85, 30, 2, 2);
  ellipse(10, 15, 2, 2);
  ellipse(18, 30, 2, 2);
  ellipse(15, 10, 2, 2);
  ellipse(25, 20, 2, 2);
  ellipse(5, 25, 2, 2);
}
function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  colorMode(RGB, 255, 255, 255, 1);
  stroke(0, 255, 0, 1);
  fill(0, 255, 0);
  arc(100, 300, 100, 100, 0, TWO_PI, PIE);
  stroke(255, 0, 0, 1);
  fill(255, 0, 0);
  triangle(50, 220, 220, 125, 200, 275);
  stroke(255, 120, 100, 1);
  fill(255, 120, 100);
  triangle(50, 100, 250, 10, 325, 50);
  beginShape();
  stroke(255, 165, 0, 1);
  curveVertex(300, 50);
  curveVertex(300, 50);
  curveVertex(300, 150);
  curveVertex(250, 100);
  curveVertex(250,100);
  curveVertex(50, 100);
  curveVertex(200, 50);
  curveVertex(200,50);
  curveVertex(200, 20);
  curveVertex(250, 0);
  curveVertex(250, 0);
  curveVertex(300, 20);
  curveVertex(300, 50);
  curveVertex(300, 50);
  fill(255, 165, 0);
  endShape();
}
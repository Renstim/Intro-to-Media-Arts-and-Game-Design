function setup() {
  createCanvas(400, 400);
}

let img1;
let img2;
let gif;

function preload() {
  img1 = loadImage('Matchstick.jpg');
  //img2 = loadImage();
  //gif = loadImage();
}

function draw() {
  background(220);
  //if x < 200 && y < 200
  //image();
  //set coordinates
  //image();
  // if x > 200 && y > 200
  //image();
}